## Setting Up Kabarak Hostel Complaints System

### Prerequisites
- Ensure XAMPP is installed.
- Unzip the project if necessary.

### Getting Started
1. **Start XAMPP Services**
   - Open XAMPP and start Apache and MySQL.

2. **Import Database**
   - Open phpMyAdmin (`http://localhost/phpmyadmin`).
   - Create a new database named `kabarak_hostel_complaints`.(`utils\kabarak_hostel_complaints.sql`)
   - Navigate to the `kabarak_hostel_complaints` db and click the sql nav tab and add the code feom `utils/default_user.sql` to set up default users.

3. **Run the Server**
   - Open the project folder in VS Code.
   - Launch the Node.js server with `node server.js`.

4. **Access the Application**
   - Open your web browser and go to [http://localhost:3000](http://localhost:3000).

### Notes
- Ensure all dependencies are installed (`npm install`).
- Modify database credentials in `server.js` if needed.
