const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(session({
  secret: '4b8e2cb04e1d12b39b6a4cf0dd2d4e0c6a6e3b4c06e8f2e1b6f8a4b8c6d2e4f0',
  resave: false,
  saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));

const adminRoutes = require('./routes/admin');
const registerRoutes = require('./routes/register');
const staffRoutes = require('./routes/staff');
const studentRoutes = require('./routes/student');

app.use('/admin', adminRoutes);
app.use('/register', registerRoutes); // Ensure this path matches the route prefix
app.use('/staff', staffRoutes);
app.use('/student', studentRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
