-- Insert Admin Data
INSERT INTO admin (email, username, password) VALUES ('admin@example.com', 'admin', 'adminpassword');

-- Insert Staff Data
INSERT INTO staff (email, password) VALUES ('staff1@example.com', 'staffpassword1'), ('staff2@example.com', 'staffpassword2');

-- Insert Student Data
INSERT INTO students (name, email, password) VALUES ('Student One', 'student1@example.com', 'studentpassword1'), ('Student Two', 'student2@example.com', 'studentpassword2');
