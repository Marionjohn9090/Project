const express = require('express');
const router = express.Router();
const pool = require('../db_connection');
const path = require('path');
const session = require('express-session');

// Configure express-session
router.use(session({
  secret: '4b8e2cb04e1d12b39b6a4cf0dd2d4e0c6a6e3b4c06e8f2e1b6f8a4b8c6d2e4f0', // Replace with your secure random key
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/student-login.html'));
});

router.post('/login', (req, res) => {
  const { student_id, password } = req.body;
  console.log('Received login request for student_id:', student_id);

  const query = 'SELECT * FROM students WHERE student_id = ? AND password = ?';
  pool.query(query, [student_id, password], (err, results) => {
    if (err) {
      console.error('Error logging in:', err);
      return res.status(500).send('Error occurred');
    }
    console.log('Database query results:', results);
    if (results.length > 0) {
      req.session.student = results[0]; // Store student data in session
      res.redirect('/student/dashboard');
    } else {
      res.status(401).send('Invalid credentials');
    }
  });
});

router.get('/dashboard', (req, res) => {
  if (!req.session.student) {
    return res.redirect('/student/login');
  }
  res.sendFile(path.join(__dirname, '../public/student-dashboard.html'));
});

router.post('/place_complaint', (req, res) => {
  if (!req.session.student) {
    return res.status(401).send('Unauthorized');
  }
  const { complaint_description } = req.body;
  const studentId = req.session.student.student_id; // Retrieve student ID from session

  // Insert the complaint into the database
  pool.query('INSERT INTO complaints (student_id, complaint_description) VALUES (?, ?)', [studentId, complaint_description], (err, results) => {
    if (err) {
      console.error('Error inserting complaint:', err);
      return res.status(500).send('Error occurred');
    }
    console.log('Complaint placed successfully');
    res.send('Complaint placed successfully');
  });
});

router.get('/view_complaints', (req, res) => {
  if (!req.session.student) {
    return res.status(401).send('Unauthorized');
  }
  const studentId = req.session.student.student_id;

  // Fetch complaints for the logged-in student
  pool.query('SELECT * FROM complaints WHERE student_id = ?', [studentId], (err, results) => {
    if (err) {
      console.error('Error fetching complaints:', err);
      return res.status(500).send('Error occurred');
    }
    res.json(results);
  });
});

module.exports = router;
