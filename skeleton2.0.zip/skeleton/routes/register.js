const express = require('express');
const router = express.Router();
const pool = require('../db_connection'); // Adjust the path if needed

// Handle staff registration
router.post('/register_staff', (req, res) => {
  const { staff_email, staff_password } = req.body;

  if (!staff_email || !staff_password) {
    return res.status(400).send('Email and Password are required.');
  }

  // Insert new staff into the database
  pool.query('INSERT INTO staff (email, password) VALUES (?, ?)', [staff_email, staff_password], (err, results) => {
    if (err) {
      console.error('Error inserting staff:', err);
      return res.status(500).send('Failed to register staff.');
    }
    res.status(200).send('Staff registered successfully.');
  });
});

// Handle student registration
router.post('/register_student', (req, res) => {
  const { student_id, student_name, student_email, student_password } = req.body;

  if (!student_id || !student_name || !student_email || !student_password) {
    return res.status(400).send('Student ID, Name, Email, and Password are required.');
  }

  // Insert new student into the database
  pool.query('INSERT INTO students (student_id, name, email, password) VALUES (?, ?, ?, ?)', [student_id, student_name, student_email, student_password], (err, results) => {
    if (err) {
      console.error('Error inserting student:', err);
      return res.status(500).send('Failed to register student.');
    }
    res.status(200).send('Student registered successfully.');
  });
});

module.exports = router;
