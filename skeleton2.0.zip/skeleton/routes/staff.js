const express = require('express');
const router = express.Router();
const pool = require('../db_connection');
const path = require('path');
const session = require('express-session');

// Configure express-session
router.use(session({
  secret: '4b8e2cb04e1d12b39b6a4cf0dd2d4e0c6a6e3b4c06e8f2e1b6f8a4b8c6d2e4f0', // Replace with your secure random key
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/staff-login.html'));
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  pool.query('SELECT * FROM staff WHERE email = ? AND password = ?', [email, password], (err, results) => {
    if (err) {
      console.error('Database query error:', err); // Log query error
      return res.status(500).send('Error occurred');
    }
    if (results.length > 0) {
      req.session.staff = results[0];
      console.log('Session:', req.session); // Log session data for debugging
      res.redirect('/staff/dashboard'); 
    } else {
      res.status(401).send('Invalid credentials');
    }
  });
});

router.get('/dashboard', (req, res) => {
  if (!req.session.staff) {
    return res.redirect('/staff/login');
  }
  res.sendFile(path.join(__dirname, '../public/staff-dashboard.html'));
});

router.get('/view_tasks', (req, res) => {
  if (!req.session.staff) {
    return res.status(401).send('Unauthorized');
  }
  const staffId = req.session.staff.staff_id; // Adjust according to your database schema
  console.log('Fetching tasks for Staff ID:', staffId); // Log staff ID for debugging
  pool.query('SELECT * FROM tasks WHERE staff_id = ?', [staffId], (err, results) => {
    if (err) {
      console.error('Database query error:', err); // Log query error
      return res.status(500).send('Error occurred');
    }
    console.log('Tasks retrieved:', results); // Log results for debugging
    res.json(results);
  });
});

module.exports = router;
