const express = require('express');
const router = express.Router();
const pool = require('../db_connection');
const path = require('path');
const session = require('express-session');

// Configure express-session
router.use(session({
  secret: '4b8e2cb04e1d12b39b6a4cf0dd2d4e0c6a6e3b4c06e8f2e1b6f8a4b8c6d2e4f0', // Replace with your secure random key
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

router.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin-login.html'));
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;

  pool.query('SELECT * FROM admin WHERE username = ? AND password = ?', [username, password], (err, results) => {
    if (err) {
      return res.status(500).send('Error occurred');
    }
    if (results.length > 0) {
      req.session.admin = results[0]; // Store admin data in session
      res.redirect('/admin/dashboard');
    } else {
      res.status(401).send('Invalid credentials');
    }
  });
});

router.get('/dashboard', (req, res) => {
  if (!req.session.admin) {
    return res.redirect('/admin/login');
  }
  res.sendFile(path.join(__dirname, '../public/admin-dashboard.html'));
});

router.post('/remove_staff', (req, res) => {
  if (!req.session.admin) {
    return res.status(403).send('Unauthorized');
  }
  const { staff_id } = req.body;
  pool.query('DELETE FROM staff WHERE staff_id = ?', [staff_id], (err) => {
    if (err) {
      return res.status(500).send('Error occurred');
    }
    res.send('Staff member removed successfully');
  });
});

router.post('/assign_task', (req, res) => {
  if (!req.session.admin) {
    return res.status(403).send('Unauthorized');
  }
  
  const { staff_id, task_description } = req.body;

  pool.query('INSERT INTO tasks (staff_id, task_description) VALUES (?, ?)', [staff_id, task_description], (err) => {
    if (err) {
      console.error('Error inserting task:', err); // Log the error to the console
      return res.status(500).send('Error occurred while assigning task');
    }
    res.send('Task assigned successfully');
  });
});


router.get('/view_staff', (req, res) => {
  if (!req.session.admin) {
    return res.status(403).send('Unauthorized');
  }
  pool.query('SELECT staff_id, email FROM staff', (err, results) => {
    if (err) {
      return res.status(500).send('Error occurred');
    }
    res.json(results);
  });
});

router.get('/view_complaints', (req, res) => {
  if (!req.session.admin) {
    return res.status(403).send('Unauthorized');
  }
  pool.query('SELECT * FROM complaints', (err, results) => {
    if (err) {
      return res.status(500).send('Error occurred');
    }
    res.json(results);
  });
});

module.exports = router;
